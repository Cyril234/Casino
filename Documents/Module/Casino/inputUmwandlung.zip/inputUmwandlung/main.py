#from inputButton import inputButton
from inputRFID import inputRFID
from time import sleep

while True:
    #inputButton()
    inputRFID()
    sleep(0.05)